package com.example.jacob.bmicalc;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class ResultsActivity extends AppCompatActivity {

    private TextView mHeight, mWeight, mBMI, mBMI_GROUP;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        setupToolbar();
        setupFAB();
        setupViews();
        processIncomingData();

    }

    private void processIncomingData() {
        Bundle extras = getIntent().getExtras();
        double height = extras.getDouble("HEIGHT");
        double weight = extras.getDouble("WEIGHT");
        String BMI = extras.getString("BMI");
        String BMI_Group = extras.getString("BMI_GROUP");

        String strHeight = getString(R.string.height_inches) + " :" + height;
        String strWeight = getString(R.string.weight_pounds) + " :" + weight;
        String strBMI = getString(R.string.BMI) + " :" + BMI;
        String strBMI_Group = getString(R.string.BMI_Group) + " :" + BMI_Group;

        mHeight.setText(strHeight);
        mWeight.setText(strWeight);
        mBMI.setText(strBMI);
        mBMI_GROUP.setText(strBMI_Group);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupViews() {
        mHeight = findViewById(R.id.tv_height);
        mWeight = findViewById(R.id.tv_weight);
        mBMI = findViewById(R.id.tv_BMI);
        mBMI_GROUP = findViewById(R.id.tv_BMI_Group);
    }

    private void setupFAB() {
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

}
